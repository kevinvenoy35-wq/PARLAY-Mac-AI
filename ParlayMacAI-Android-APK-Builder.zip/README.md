# Parlay Mac AI Android

This is a real Android app project. It works offline and includes:

- AI matchup calculator
- NBA, WNBA, NFL, MLB and college sports
- No-vig calculator
- Parlay builder
- Bet tracker saved on the phone
- Bankroll unit guide

## Build the APK with GitHub

1. Create a new GitHub repository.
2. Upload every file and folder from this project.
3. Open the repository's **Actions** tab.
4. Open **Build Parlay Mac APK**.
5. Tap **Run workflow**.
6. When it finishes, open the completed run.
7. Download the **Parlay-Mac-AI-APK** artifact.
8. Extract it and install `app-debug.apk`.

Android may ask you to allow installation from your browser or Files app.

This first version is offline. It does not automatically pull live odds, injuries, schedules, or scores.