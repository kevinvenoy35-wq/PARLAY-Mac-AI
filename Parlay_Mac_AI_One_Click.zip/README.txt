
PARLAY MAC AI — ONE CLICK VERSION

FIRST TIME:
1. Double-click INSTALL_AND_RUN.bat
2. Wait while it installs what is needed.
3. Your browser should open automatically.

AFTER THE FIRST TIME:
1. Double-click RUN_PARLAY_MAC_AI.bat

IMPORTANT:
Keep this whole folder together. Do not move app.py by itself.
