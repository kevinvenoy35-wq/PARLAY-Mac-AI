@echo off
title Install and Run Parlay Mac AI
cd /d "%~dp0"
echo Installing required programs...
py -m pip install --upgrade pip
py -m pip install streamlit pandas
echo.
echo Starting Parlay Mac AI...
py -m streamlit run app.py
pause
