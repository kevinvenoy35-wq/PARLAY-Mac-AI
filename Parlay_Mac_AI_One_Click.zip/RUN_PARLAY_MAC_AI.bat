@echo off
title Parlay Mac AI
cd /d "%~dp0"
echo Starting Parlay Mac AI...
py -m streamlit run app.py
pause
